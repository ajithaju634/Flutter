import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

// class MyHomePage extends StatelessWidget {
//   const MyHomePage({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('appable'),
//         centerTitle: true,
//         actions: [Icon(Icons.account_box_rounded)],
//         leading: Icon(Icons.menu),
//         backgroundColor: Colors.amber,
//       ),
//       body: Container(
//         width: 800,
//         height: 800,
//         color: Colors.blueGrey,
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text('hey'),
//             Text(
//               'Explore',
//               style: TextStyle(fontWeight: FontWeight.bold),
//             ),
//             TextField(
//                 decoration: InputDecoration(
//                     hintText: 'search',
//                     suffixIcon: Icon(Icons.mic),
//                     border: OutlineInputBorder())),
//             Container(
//               color:Colors.deepPurple,
//               width: 60,
//               height: 60,
//               child: Center(
//                 child: Text('JS'),

//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }

class MyHomepage extends StatelessWidget {
  const MyHomepage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        actions: [Icon(Icons.account_box_rounded)],
        leading: Icon(Icons.menu),
        title: const Text('/appable:'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: 800,
          height: 800,
          color: Color.fromARGB(255, 218, 229, 230),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Text('Hey,Coding with T'),
                ),
                Padding(
                    padding: EdgeInsets.only(left: 10),
                    child: Text(
                      'Explore Course',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                    )),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    decoration: InputDecoration(
                        hintText: "Search",
                        suffixIcon: Icon(Icons.mic),
                        border: OutlineInputBorder()),
                  ),
                ),
                Row(
                  children: <Widget>[
                    SizedBox(
                      width: 20,
                    ),
                    Container(
                      width: 60,
                      height: 60,
                      child: Center(
                        child: Text(
                          'JS',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(20)),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Column(
                      children: [Text('Java Script'), Text('10 lessons')],
                    ),
                    SizedBox(
                      width: 120,
                    ),
                    Container(
                      width: 60,
                      height: 60,
                      child: Center(
                        child: Text(
                          'F',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(20)),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Column(
                      children: [Text('Flutter'), Text('11 Lessons')],
                    ),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  children: [
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      width: 200,
                      height: 200,
                      color: Color.fromARGB(255, 238, 236, 236),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Icon(Icons.favorite_border),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 80),
                            child: Image.asset("asset/abd.jpeg"),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 80),
                            child: Text(
                              "Android for \n Beginners",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 50,
                    ),
                    Container(
                      width: 200,
                      height: 200,
                      color: const Color.fromARGB(255, 243, 236, 236),
                      child: Column(
                        children: [
                          Row(
                            children: [Icon(Icons.favorite_border)],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 80),
                            child: Image.asset("asset/abd.jpeg"),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 120),
                            child: Text(
                              'JAVA',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          ElevatedButton(
                              onPressed: () {}, child: Text("view all"))
                        ],
                      ),
                    ),
                  ],
                ),
                Text(
                  'Top Courses',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: 500,
                    height: 400,
                    color: const Color.fromARGB(255, 236, 234, 234),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Flutter crash\n course',
                            textAlign: TextAlign.right,
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 300),
                            child: Image.asset("asset/abd.jpeg"),
                          ),
                          Container(
                            width: 600,
                            height: 100,
                            color: Color.fromARGB(255, 229, 227, 226),
                            child: Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 24, 23, 23),
                                        borderRadius:
                                            BorderRadius.circular(50)),
                                    width: 50,
                                    height: 50,
                                    child: Center(
                                      child: Icon(
                                        Icons.video_collection_outlined,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  "3 Section",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                Text('\nprograming languages')
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
